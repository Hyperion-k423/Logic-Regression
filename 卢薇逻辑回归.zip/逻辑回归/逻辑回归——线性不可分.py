import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
path='ex2data2.txt'
data=pd.read_csv(path,names=['Test 1','Test 2','Accepted'])
data.head()

fig,ax=plt.subplots()
ax.scatter(data[data['Accepted']==0]['Test 1'],data[data['Accepted']==0]['Test 2'],c='r',marker='x',label='y=0')
ax.scatter(data[data['Accepted']==1]['Test 1'],data[data['Accepted']==1]['Test 2'],c='b',marker='o',label='y=1')
ax.legend()
ax.set(xlabel='Test1',
       ylabel='Test2')

# 特征映射
def feature_mapping(x1,x2,power):
    data={}

    for i in np.arange(power+1):
        for j in np.arange(i+1):
            data['F{}{}'.format(i-j,j)]=np.power(x1,i-j)*np.power(x2,j)
    return pd.DataFrame(data)

x1=data['Test 1']
x2=data['Test 2']

data2=feature_mapping(x1,x2,6)


# 构造数据集
X=data2.values

y=data.iloc[:,-1].values

y=y.reshape(len(y),1)


def sigmoid(z):
    return 1/(1+np.exp(-z))

def costFunction(X,y,theta,lr):
    A=sigmoid(x@theta)
    first=y*np.log(A)
    second=(1-y)*np.log(1-A)

    reg=np.sum(np.power(theta[1:],2))*(lr/(2*len(X)))


    return np.sum(first+second)/len(X)+reg

theta=np.zeros(((28,1)))


lr=1

cost_init=costFunction(X,y,theta,lr)


def gradientDescent(X,y,theta,alpha,iters,lr):

    costs=[]

    for i in range(iters):

        reg=theta[1:]*(lr/len(X))
        reg=np.insert(reg,0,values=0,axis=0)

        theta=theta-(X.T@(sigmoid(X@theta)-y))*alpha/len(X)-reg
        cost=costFunction(X,y,theta,lr)
        costs.append(cost)

        if i%100==0:
            print(cost)

    return theta,costs

alpha=0.001
iters=200000
lr=0.001

theta_fina,costs=gradientDescent(X.y,theta,alpha,iters,lr)

def predict(X,theta):
    prob=sigmoid(X@theta)
    return [1 if x>=0.5 else 0 for x in prob]

y-=np.array(predict(X,theta_final))
y_pre=y_.reshape(len(y_),1)

acc=np.mean(y_pre==y)

print(acc)

